from db import get_connection
from flask import Flask, request, render_template, redirect, url_for
from modules.attendance.routes import attendance_bp
from flask import session
from datetime import datetime


app = Flask(__name__)



#login system start__________________________________
import pyodbc

app.secret_key = "secret123"


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = get_connection()
        cursor = conn.cursor()

        cursor.execute("SELECT * FROM users WHERE username=? AND password=?", (username, password))
        user = cursor.fetchone()

        if user:
            session['user'] = username
            return redirect('/dashboard')   # ✅ FIX
        else:
            return "Invalid login"

    return render_template('login.html')


@app.route('/')
def home():
    if 'user' in session:
        return redirect('/dashboard')   
    return redirect('/login')           





#Login system end_____________________________________









@app.route('/dashboard')
def dashboard():
    conn = get_connection()
    cursor = conn.cursor()

    today = datetime.now().strftime('%Y-%m-%d')

    # 🔥 total employees
    cursor.execute("SELECT COUNT(*) FROM employee")
    total_employees = cursor.fetchone()[0]

    # 🔥 present today
    cursor.execute("""
    SELECT COUNT(*)
    FROM attendance
    WHERE date=? AND status='Present'
    """, (today,))
    present_today = cursor.fetchone()[0]

    # 🔥 absent today
    cursor.execute("""
    SELECT COUNT(*)
    FROM attendance
    WHERE date=? AND status='Absent'
    """, (today,))
    absent_today = cursor.fetchone()[0]

    # 🔥 total payroll (simple current month)
    cursor.execute("SELECT SUM(salary) FROM employee")
    total_salary = cursor.fetchone()[0] or 0

    # 🔥 recent attendance (name + status)
    cursor.execute("""
    SELECT e.name, a.status
    FROM attendance a
    JOIN employee e ON a.emp_id = e.id
    WHERE a.date=?
    """, (today,))
    
    rows = cursor.fetchall()

    # convert to dict for Jinja
    recent_attendance = []
    for r in rows:
        recent_attendance.append({
            "name": r[0],
            "status": r[1]
        })

    conn.close()

    return render_template(
        'dashboard.html',
        total_employees=total_employees,
        present_today=present_today,
        absent_today=absent_today,
        total_salary=round(total_salary, 2),
        recent_attendance=recent_attendance
    )

# Home → employees page
@app.route('/')
def home2():
    return redirect(url_for('dashboard'))


# Employees list
@app.route('/employees')
def show_employees():
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM employee")
    data = cursor.fetchall()
    conn.close()
    return render_template('employees.html', data=data)


# Add employee page (form)
@app.route('/add_employee')
def add_employee_page():
    return render_template('add_employee.html')


# Form submit (POST only)
@app.route('/add', methods=['POST'])
def add():
    code = request.form['code']
    name = request.form['name']
    salary = request.form['salary']
    dept = request.form['dept']

    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute(
        "INSERT INTO employee (code,name, salary, dept) VALUES (?,?, ?, ?)",
        (code,name, salary, dept)
    )
    conn.commit()
    conn.close()

    return redirect(url_for('show_employees'))


@app.route('/delete/<int:id>')
def delete_employee(id):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM employee WHERE id = ?", (id,))
    
    conn.commit()
    conn.close()

    return redirect(url_for('show_employees'))



#editemployee

@app.route('/edit/<int:id>')
def edit_employee(id):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT * FROM employee WHERE id = ?", (id,))
    emp = cursor.fetchone()

    conn.close()

    return render_template('edit_employees.html', emp=emp)


#update employee

@app.route('/update/<int:id>', methods=['POST'])
def update_employee(id):
    code = request.form['code']
    name = request.form['name']
    salary = request.form['salary']
    dept = request.form['dept']

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute(
        "UPDATE employee SET code=?, name=?, salary=?, dept=? WHERE id=?",
        (code,name, salary, dept, id)
    )

    conn.commit()
    conn.close()

    return redirect(url_for('show_employees'))

# attendance system

app.register_blueprint(attendance_bp)

@app.route('/attendance')
def attendance():
    conn = get_connection()
    cursor = conn.cursor()

    # ID bhi lao (hidden use ke liye)
    cursor.execute("SELECT id, code, name FROM employee")
    data = cursor.fetchall()

    conn.close()

    return render_template('employee_attendance.html', data=data)












#employe_details

# employee details page (DISPLAY)

@app.route('/employee/<int:id>')
def employee_details(id):
    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
SELECT e.id, e.code, e.name, e.dept, e.salary,
       p.first_name, p.last_name,p.father_name,p.mother_name, p.gender,
       p.date_of_birth, p.joining_date,
       p.mobile1, p.email, p.address,city,district,pincode,age,qualification,
        marital_status,designation,driving_license,pan,aadhaar,blood_group,esi_no,epf_no,p.allow_cl
FROM employee e
LEFT JOIN personal_info p ON e.id = p.id
WHERE e.id = ?
""", (id,))

    data = cursor.fetchone()
    conn.close()

    return render_template('employee_details.html', data=data)

@app.route('/save_details/<int:id>', methods=['POST'])
def save_details(id):
    
    first_name = request.form['first_name']
    last_name = request.form['last_name']
    gender = request.form['gender']
    dob = request.form['dob']
    doj = request.form['doj']
    father = request.form['father_name']
    mother = request.form['mother_name']
    mobile = request.form['mobile1']
    email = request.form['email']
    address = request.form['address']
    city = request.form['city']
    district = request.form['district']
    pincode = request.form['pincode']
    age = request.form['age']
    qualification = request.form['qualification']
    marital_status = request.form['marital_status']
    designation = request.form['designation']
    driving_license = request.form['driving_license']
    pan = request.form['pan']
    aadhaar = request.form['aadhaar']
    blood_group = request.form['blood_group']
    esi_no = request.form['esi_no']
    epf_no = request.form['epf_no']
    allow_cl = int(request.form.get('allow_cl') or 0)

    conn = get_connection()
    cursor = conn.cursor()

    # 🔍 Check if record already exists
    cursor.execute("SELECT id FROM personal_info WHERE id = ?", (id,))
    exists = cursor.fetchone()

    if exists:
        # 🔄 UPDATE
        cursor.execute("""
        UPDATE personal_info
        SET first_name=?, last_name=?, gender=?,
            father_name=?, mother_name=?,
            date_of_birth=?, joining_date=?,
            mobile1=?, email=?, address=?,city=?
            ,district=?,pincode=?,age=?,qualification=?,
            marital_status=?,designation=?,driving_license=?,
            pan=?,aadhaar=?,blood_group=?,esi_no=?,epf_no=?,allow_cl=?
        WHERE id=?
        """,
        (first_name, last_name, gender,
         father, mother,
         dob, doj,
         mobile, email, address,city,district,pincode,age,qualification,marital_status,designation,driving_license,pan,aadhaar,blood_group,esi_no,epf_no,allow_cl, id)
        )
    else:
        # ➕ INSERT
        cursor.execute("""
        INSERT INTO personal_info
        (id, first_name, last_name, gender, father_name, mother_name,
         date_of_birth, joining_date, mobile1, email, address,city,district,pincode,age,qualification,marital_status,designation,driving_license,pan,aadhaar,blood_group,esi_no,epf_no,allow_cl)
        VALUES (?,?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """,
        (id, first_name, last_name, gender,
         father, mother,
         dob, doj,
         mobile, email, address,city,district,pincode,age,qualification,marital_status,designation,driving_license,pan,aadhaar,blood_group,esi_no,epf_no,allow_cl)
        )

    conn.commit()
    conn.close()

    return redirect(url_for('employee_details', id=id))


#import_function_________________________________________________





if __name__ == '__main__':
    app.run(debug=True)






