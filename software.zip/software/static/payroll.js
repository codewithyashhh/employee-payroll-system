
// Net salary calculate
function calculatePayroll()
{
let table = document.getElementById("payrollTable");

for(let i=1; i<table.rows.length; i++)
{
let basic = parseInt(table.rows[i].cells[2].innerText);

let bonus = parseInt(table.rows[i].cells[3].innerText);

let deduction = parseInt(table.rows[i].cells[4].innerText);

let net = basic + bonus - deduction;

table.rows[i].cells[5].innerText = net;
}
}

// View payroll details
function viewPayroll(button)
{
let row = button.parentElement.parentElement;

let id = row.cells[0].innerText;

let name = row.cells[1].innerText;

let net = row.cells[5].innerText;

alert(
"Employee ID: " + id +
"\nName: " + name +
"\nNet Salary: " + net
);
}

// Run when page loads
calculatePayroll();