function saveEmployee()
{
    alert("Employee Saved Successfully");

    window.location.href = "../employees.html";
}

function goBack()
{
    window.location.href = "../employees.html";
}
function saveEmployee(){

let employee = {

id: document.getElementById("empId").value,

name: document.getElementById("empName").value,

deptartment: document.getElementById("empDept").value,

salary: document.getElementById("empSalary").value

};
let employees = JSON.parse(localStorage.getItem("employees")) || [];

employees.push (employee);

localStorage.setItem("employees", JSON.stringify(employees));

window.location.href = "../employees.html";

}