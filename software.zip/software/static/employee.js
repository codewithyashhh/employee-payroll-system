window.onload = function(){

let employees = JSON.parse(localStorage.getItem("employees")) || [];

let table = document.getElementById("employeeTable");

employees.forEach(emp => {

let row = table.insertRow();

row.insertCell(0).innerText = emp.id;
row.insertCell(1).innerText = emp.name;
row.insertCell(2).innerText = emp.dept;
row.insertCell(3).innerText = emp.salary;

});

}