from flask import Blueprint, request, render_template, redirect, url_for
from db import get_connection
import calendar
from datetime import datetime


attendance_bp = Blueprint('attendance', __name__)

@attendance_bp.route('/calendar/<int:id>')
def calendar_view(id):

    conn = get_connection()
    cursor = conn.cursor()

    today = datetime.now()
    month = int(request.args.get('month', today.month))
    year = int(request.args.get('year', today.year))

    start_date = f"{year}-{month:02d}-01"

    if month == 12:
        end_date = f"{year+1}-01-01"
    else:
        end_date = f"{year}-{month+1:02d}-01"

    # 🔥 attendance data
    cursor.execute("""
        SELECT date, status
        FROM attendance
        WHERE emp_id=? AND date >= ? AND date < ?
    """, (id, start_date, end_date))

    records = cursor.fetchall()

    attendance_dict = {}
    for r in records:
        day = r[0].day if hasattr(r[0], 'day') else int(str(r[0]).split('-')[2])
        attendance_dict[day] = r[1]

    # 🔥 leave balance (IMPORTANT: close se pehle)
    cursor.execute("""
    SELECT cl_balance, sl_balance, cpl_balance
    FROM employee
    WHERE id=?
    """, (id,))

    balance = cursor.fetchone()

    # 🔥 FIX START
    if balance is None:
      cl_bal = 0
      sl_bal = 0
      cpl_bal = 0
    else:
      cl_bal = float(balance[0] or 0)
      sl_bal = float(balance[1] or 0)
      cpl_bal = float(balance[2] or 0)
# 🔥 FIX END

# 🔥 SAME LEVEL indentation
    cal = calendar.monthcalendar(year, month)

    conn.close()


    return render_template(
    'calendar.html',
    cal=cal,
    attendance=attendance_dict,
    month=month,
    year=year,
    emp_id=id,
    cl_bal=cl_bal,
    sl_bal=sl_bal,
    cpl_bal=cpl_bal
)

@attendance_bp.route('/mark/<int:emp_id>/<int:year>/<int:month>/<int:day>', methods=['POST'])
def mark_attendance(emp_id, year, month, day):

    conn = get_connection()
    cursor = conn.cursor()

    date = f"{year}-{month:02d}-{day:02d}"
    new_status = request.form.get('status')

    if not new_status:
        return redirect(url_for(
            'attendance.calendar_view',
            id=emp_id,
            month=month,
            year=year
        ))

    # 🔥 fetch current balance
    cursor.execute("""
    SELECT cl_balance, sl_balance, cpl_balance 
    FROM employee WHERE id=?
    """, (emp_id,))
    bal = cursor.fetchone()

    cl = float(bal[0] or 0)
    sl = float(bal[1] or 0)
    cpl = float(bal[2] or 0)

    # 🔥 check existing record
    cursor.execute("""
    SELECT status FROM attendance
    WHERE emp_id=? AND date=?
    """, (emp_id, date))
    record = cursor.fetchone()

    old_status = record[0] if record else None

    # 🔥 function: restore old leave
    def restore(status):
        nonlocal cl, sl, cpl
        if status == "CL": cl += 1
        elif status == "Half CL": cl += 0.5
        elif status == "SL": sl += 1
        elif status == "Half SL": sl += 0.5
        elif status == "CPL": cpl += 1
        elif status == "Half CPL": cpl += 0.5

    # 🔥 function: deduct new leave
    def deduct(status):
        nonlocal cl, sl, cpl
        if status == "CL" and cl >= 1:
            cl -= 1
            return True
        elif status == "Half CL" and cl >= 0.5:
            cl -= 0.5
            return True
        elif status == "SL" and sl >= 1:
            sl -= 1
            return True
        elif status == "Half SL" and sl >= 0.5:
            sl -= 0.5
            return True
        elif status == "CPL" and cpl >= 1:
            cpl -= 1
            return True
        elif status == "Half CPL" and cpl >= 0.5:
            cpl -= 0.5
            return True
        elif status in ["Present", "Absent", "Half Day", "Weekly Off"]:
            return True
        return False

    # 🔥 restore old
    if old_status:
        restore(old_status)

    # 🔥 try deduct new
    allowed = deduct(new_status)

    if not allowed:
        conn.close()
        return redirect(url_for(
            'attendance.calendar_view',
            id=emp_id,
            month=month,
            year=year
        ))

    # 🔥 save attendance
    if record:
        cursor.execute("""
        UPDATE attendance SET status=?
        WHERE emp_id=? AND date=?
        """, (new_status, emp_id, date))
    else:
        cursor.execute("""
        INSERT INTO attendance (emp_id, date, status)
        VALUES (?, ?, ?)
        """, (emp_id, date, new_status))

    # 🔥 update balances in DB
    cursor.execute("""
    UPDATE employee
    SET cl_balance=?, sl_balance=?, cpl_balance=?
    WHERE id=?
    """, (cl, sl, cpl, emp_id))

    conn.commit()
    conn.close()

    return redirect(url_for(
        'attendance.calendar_view',
        id=emp_id,
        month=month,
        year=year
    ))

    # 🔥 save attendance

    cursor.execute(
        "SELECT status FROM attendance WHERE emp_id=? AND date=?",
        (emp_id, date)
    )
    record = cursor.fetchone()

    if record:
        cursor.execute("""
        UPDATE attendance SET status=? 
        WHERE emp_id=? AND date=?
        """, (status, emp_id, date))
    else:
        cursor.execute("""
        INSERT INTO attendance (emp_id, date, status)
        VALUES (?, ?, ?)
        """, (emp_id, date, status))

    conn.commit()
    conn.close()

    return redirect(url_for(
        'attendance.calendar_view',
        id=emp_id,
        month=month,
        year=year
    ))
#leave syste,.............................................       


@attendance_bp.route('/leave', methods=['GET', 'POST'])
def leave():

    conn = get_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        emp_id = request.form.get('emp_id')
        leave_type = request.form.get('leave_type')
        action = request.form.get('action')
        days = float(request.form.get('days'))

        # current balance fetch
        cursor.execute("""
        SELECT cl_balance, sl_balance, cpl_balance 
        FROM employee WHERE id=?
        """, (emp_id,))
        bal = cursor.fetchone()

        cl, sl, cpl = float(bal[0] or 0), float(bal[1] or 0), float(bal[2] or 0)

        # 🔥 logic
        if leave_type == "CL":
            cl = cl + days if action == "add" else cl - days

        elif leave_type == "SL":
            sl = sl + days if action == "add" else sl - days

        elif leave_type == "CPL":
            cpl = cpl + days if action == "add" else cpl - days

        # update DB
        cursor.execute("""
        UPDATE employee
        SET cl_balance=?, sl_balance=?, cpl_balance=?
        WHERE id=?
        """, (cl, sl, cpl, emp_id))

        conn.commit()

    # show employees
    cursor.execute("""
    SELECT id, code, name, cl_balance, sl_balance, cpl_balance
    FROM employee
    """)
    employees = cursor.fetchall()

    conn.close()

    return render_template("leave.html", data=employees)

#payroll__________________________________________________________________
@attendance_bp.route('/payroll')
def payroll():

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("SELECT id, name, salary FROM employee")
    employees = cursor.fetchall()

    today = datetime.now()

    # 🔥 26–25 cycle logic
    if today.day >= 26:
        # current cycle
        start_date = f"{today.year}-{today.month:02d}-26"

        if today.month == 12:
            end_date = f"{today.year+1}-01-25"
        else:
            end_date = f"{today.year}-{today.month+1:02d}-25"

    else:
        # previous cycle
        if today.month == 1:
            start_date = f"{today.year-1}-12-26"
        else:
            start_date = f"{today.year}-{today.month-1:02d}-26"

        end_date = f"{today.year}-{today.month:02d}-25"

    payroll_data = []

    for emp in employees:
        emp_id = emp[0]
        name = emp[1]
        salary = float(emp[2])

        # 🔥 attendance fetch (IMPORTANT: <= 25 include karna hai)
        cursor.execute("""
        SELECT status
        FROM attendance
        WHERE emp_id=? AND date >= ? AND date <= ?
        """, (emp_id, start_date, end_date))

        records = cursor.fetchall()

        # 🔥 paid days calculation
        paid_days = 0

        for r in records:
            status = r[0]

            if status == "Present":
                paid_days += 1

            elif status == "Half Day":
                paid_days += 0.5

            elif status in ["CL", "CPL", "SL", "Weekly Off"]:
                paid_days += 1

            elif status in ["Half CL", "Half CPL", "Half SL"]:
                paid_days += 0.5


           # 🔥 OT + GP fetch
        cursor.execute("""
        SELECT type, SUM(hours)
        FROM extra_entries
        WHERE emp_id=? AND entry_date >= ? AND entry_date < ?
        GROUP BY type
        """, (emp_id, start_date, end_date))

        extras = cursor.fetchall()

        ot_hours = 0
        gp_hours = 0

        for e in extras:
         if e[0] == 'OT':
          ot_hours = float(e[1])
         elif e[0] == 'GP':
          gp_hours = float(e[1])


        # 🔥 salary calculation
        daily_salary = salary / 30
        hourly_salary = daily_salary / 8

        base_salary = daily_salary * paid_days

        ot_pay = ot_hours * hourly_salary
        gp_deduction = gp_hours * hourly_salary

        final_salary = base_salary + ot_pay - gp_deduction       

        payroll_data.append({
    "id": emp_id,
    "name": name,
    "salary": salary,
    "paid_days": paid_days,
    "ot_hours": ot_hours,
    "gp_hours": gp_hours,
    "final_salary": round(final_salary, 2)
})

    conn.close()

    return render_template("payroll.html", data=payroll_data)






#import logic ________________________________________________
@attendance_bp.route('/employee', methods=['GET', 'POST'])
def employees():

    conn = get_connection()
    cursor = conn.cursor()

    # 🔥 IMPORT LOGIC
    if request.method == 'POST':
        import pandas as pd

        file = request.files['file']
        df = pd.read_excel(file)

        for _, row in df.iterrows():

            cursor.execute("SELECT * FROM dbo.employees WHERE code=?", (row['code'],))
            exists = cursor.fetchone()

            if not exists:
                cursor.execute("""
                INSERT INTO dbo.employees (code, name, salary, department)
                VALUES (?, ?, ?, ?)
                """, (
                    row['code'],
                    row['name'],
                    row['salary'],
                    row['department']
                ))

        conn.commit()

    # 🔽 Employee data fetch
    cursor.execute("SELECT id, code, name, salary, department FROM dbo.employees")
    data = cursor.fetchall()

    conn.close()

    return render_template("employee_attendance.html", data=data)


#extra_entrires ot and gate pass_________________________________________________________
@attendance_bp.route('/extras', methods=['GET', 'POST'])
def extras():

    conn = get_connection()
    cursor = conn.cursor()

    if request.method == 'POST':
        emp_id = int(request.form.get('emp_id'))
        date = request.form.get('date')
        entry_type = request.form.get('type')
        hours = float(request.form.get('hours') or 0)
        remark = request.form.get('remark')

        cursor.execute("""
        INSERT INTO extra_entries (emp_id, entry_date, type, hours, remark)
        VALUES (?, ?, ?, ?, ?)
        """, (emp_id, date, entry_type, hours, remark))

        conn.commit()

    cursor.execute("SELECT id, code, name FROM employee")
    employees = cursor.fetchall()

    conn.close()

    # 🔥 today's date
    today = datetime.now().strftime('%Y-%m-%d')

    return render_template("extras.html", data=employees, current_date=today)

@attendance_bp.route('/entries')
def entries():

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("""
     SELECT ex.id, e.code, e.name, ex.entry_date, ex.type, ex.hours, ex.remark
     FROM extra_entries ex
     JOIN employee e ON ex.emp_id = e.id
     ORDER BY ex.entry_date DESC
     """)

    data = cursor.fetchall()
    conn.close()

    return render_template("entries.html", data=data)

    # delete entires logic_____________________
@attendance_bp.route('/delete_entry/<int:id>')
def delete_entry(id):

    conn = get_connection()
    cursor = conn.cursor()

    cursor.execute("DELETE FROM extra_entries WHERE id=?", (id,))

    conn.commit()
    conn.close()

    return redirect(url_for('attendance.entries'))